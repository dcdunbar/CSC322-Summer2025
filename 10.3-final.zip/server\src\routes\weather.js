﻿import express from 'express';
import fetch from 'node-fetch';
import { getCache, setCache } from '../cache.js';
import { cToF } from '../utils.js';
const router = express.Router();
function keyFor(lat, lon, units) {
  const a = parseFloat(lat).toFixed(3);
  const b = parseFloat(lon).toFixed(3);
  return weather:::;
}
router.get('/', async (req, res) => {
  const { lat, lon } = req.query;
  let { units } = req.query;
  units = (units === 'metric' || units === 'imperial') ? units : 'imperial';
  if (!lat || !lon) return res.status(400).json({ error: 'lat and lon are required' });
  const cacheKey = keyFor(lat, lon, units);
  const cached = getCache(cacheKey);
  if (cached) return res.json({ source: 'cache', ...cached });
  const url = new URL('https://api.open-meteo.com/v1/forecast');
  url.searchParams.set('latitude', lat);
  url.searchParams.set('longitude', lon);
  url.searchParams.set('hourly', 'temperature_2m,relative_humidity_2m,precipitation_probability,weather_code');
  url.searchParams.set('daily', 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum');
  url.searchParams.set('current_weather', 'true');
  url.searchParams.set('timezone', 'auto');
  try {
    const r = await fetch(url.toString());
    const data = await r.json();
    if (units === 'imperial') {
      if (data?.current_weather?.temperature != null) data.current_weather.temperature = Math.round(cToF(data.current_weather.temperature));
      if (Array.isArray(data?.hourly?.temperature_2m)) data.hourly.temperature_2m = data.hourly.temperature_2m.map(v => Math.round(cToF(v)));
      if (Array.isArray(data?.daily?.temperature_2m_max)) data.daily.temperature_2m_max = data.daily.temperature_2m_max.map(v => Math.round(cToF(v)));
      if (Array.isArray(data?.daily?.temperature_2m_min)) data.daily.temperature_2m_min = data.daily.temperature_2m_min.map(v => Math.round(cToF(v)));
      data.units = 'imperial';
    } else { data.units = 'metric'; }
    const payload = { data };
    setCache(cacheKey, payload, 600);
    return res.json({ source: 'api', ...payload });
  } catch { return res.status(502).json({ error: 'Failed to fetch weather' }); }
});
export default router;
