﻿export function cToF(c){ return (c * 9/5) + 32; }\nexport function fToC(f){ return (f - 32) * 5/9; }\n
