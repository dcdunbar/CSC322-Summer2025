﻿import { useEffect, useMemo, useState } from 'react'
import { apiGet } from './api'
import ThemeWrapper from './components/ThemeWrapper'
import CurrentCard from './components/CurrentCard'
import HourlyStrip from './components/HourlyStrip'
import WeeklyGrid from './components/WeeklyGrid'
import Login from './components/Login'
import Register from './components/Register'
import PasswordChange from './components/PasswordChange'
import Settings from './components/Settings'
import Favorites from './components/Favorites'
export default function App(){
  const [lat,setLat]=useState('38.254')
  const [lon,setLon]=useState('-85.759')
  const [units,setUnits]=useState(localStorage.getItem('units')||'imperial')
  const [wx,setWx]=useState(null)
  const [loading,setLoading]=useState(false)
  const [error,setError]=useState('')
  const [token,setToken]=useState(localStorage.getItem('token')||'')
  const [view,setView]=useState('weather')
  const theme = useMemo(()=>{
    const code = wx?.data?.current_weather?.weathercode ?? 0
    if([0,1].includes(code)) return 'sunny'
    if([2,3].includes(code)) return 'cloudy'
    if([51,53,55,61,63,65,80,81,82].includes(code)) return 'rainy'
    if([71,73,75,77,85,86].includes(code)) return 'snowy'
    return 'cloudy'
  },[wx])
  async function loadWeather(l=lat, g=lon, u=units){
    setLoading(true); setError('')
    try{
      const data = await apiGet(/api/weather?lat=&lon=&units=)
      setWx(data)
    }catch(e){ setError(e.message) } finally { setLoading(false) }
  }
  useEffect(()=>{ loadWeather() },[])
  function onGeo(){
    if(!navigator.geolocation) return alert('Geolocation not supported')
    navigator.geolocation.getCurrentPosition(pos=>{
      const la = pos.coords.latitude.toFixed(3)
      const lo = pos.coords.longitude.toFixed(3)
      setLat(la); setLon(lo); loadWeather(la, lo, units)
    },()=>alert('Unable to get location'))
  }
  useEffect(()=>{ if(lat&&lon) loadWeather(lat, lon, units) },[lat,lon,units])
  function doLogout(){ localStorage.removeItem('token'); setToken(''); setView('weather') }
  function applyPrefs(p){ if(p?.units){ setUnits(p.units); localStorage.setItem('units', p.units) } if(p?.default_lat && p?.default_lon){ setLat(String(p.default_lat)); setLon(String(p.default_lon)) } }
  const unitLabel = units === 'imperial' ? 'Â°F' : 'Â°C'
  return (<ThemeWrapper theme={theme}><div className='container'><nav><h1>Weather App</h1><div className='row'><button onClick={()=>setView('weather')}>Weather</button><button onClick={()=>setView('settings')}>Settings</button>{token && <button onClick={()=>setView('password')}>Password</button>}{!token && <button onClick={()=>setView('login')}>Login</button>}{!token && <button onClick={()=>setView('register')}>Register</button>}{token && <button onClick={doLogout}>Logout</button>}</div></nav>{view==='weather' && (<div><div className='card'><div className='row' style={{justifyContent:'space-between'}}><div className='row'><input value={lat} onChange={e=>setLat(e.target.value)} placeholder='lat' style={{width:120}}/><input value={lon} onChange={e=>setLon(e.target.value)} placeholder='lon' style={{width:120}}/><button onClick={()=>loadWeather()}>Refresh</button><button onClick={onGeo}>Use My Location</button></div><div className='row' style={{gap:8, alignItems:'center'}}><select value={units} onChange={e=>{ setUnits(e.target.value); localStorage.setItem('units',e.target.value) }}><option value='imperial'>Â°F</option><option value='metric'>Â°C</option></select><div className='small'>Source: {wx?.source || '-'}</div></div></div>{loading && <div className='small'>Loading...</div>}{error && <div className='small' style={{color:'#ff9'}}>{error}</div>}</div><div className='grid'><CurrentCard data={wx?.data} unitLabel={unitLabel}/><HourlyStrip data={wx?.data} unitLabel={unitLabel}/><WeeklyGrid data={wx?.data} unitLabel={unitLabel}/>{token && <Favorites onPick={(la,lo)=>{ setLat(String(la)); setLon(String(lo)); setView('weather')}} />}</div></div>)}{view==='settings' && <Settings onApply={applyPrefs}/>} {view==='password' && token && <PasswordChange/>} {view==='login' && <Login onLogin={(tok)=>{localStorage.setItem('token',tok);setToken(tok);setView('weather')}}/>} {view==='register' && <Register onDone={()=>setView('login')}/>} <div className='small' style={{marginTop:16}}>Final snapshot â€“ Sep 4, 2025</div></div></ThemeWrapper>)
}
