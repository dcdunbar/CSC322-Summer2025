﻿# Weather App â€“ Final (10.3)
**Author:** David Dunbar  
**Title:** Weather App  
**Description:** A responsive weather app showing current, hourly, 7-day forecasts; dynamic themes; user accounts, password change, preferences, and favorites.

## Table of Contents
- Features
- Architecture
- Setup & Installation
- Usage
- Deployment
- Contributor Guidelines
- License
- References

## Features
- Real-time weather via Open-Meteo, cached in SQLite.
- Dynamic theming (sunny/rainy/snowy/cloudy).
- User accounts: register, login, logout, **password change**.
- Preferences: Â°F/Â°C and default location.
- Favorites: save named locations and load with one click.
- Responsive UI with hourly and weekly forecasts.

## Architecture
- **Client:** React + Vite (client/)
- **Server:** Node + Express + better-sqlite3 (server/)
- **DB/Cache:** SQLite (created on first run)

## Setup & Installation
### 1) Server
\\\ash
cd server
npm install
cp .env.example .env
npm start
# http://127.0.0.1:4000  (health: /api/health)
\\\
### 2) Client
\\\ash
cd client
npm install
npm run dev
# http://127.0.0.1:5173
\\\

## Usage
- Enter lat/lon or **Use My Location**.
- **Register** â†’ **Login** to access Settings, Favorites, Password Change.
- Toggle Â°F/Â°C, set default location, save favorites.

## API (quick)
- POST /api/auth/register, /api/auth/login, PATCH /api/auth/password
- GET/PUT /api/user/prefs
- GET/POST/DELETE /api/user/favorites
- GET /api/weather?lat&lon&units=imperial|metric

## Deployment
Frontend: Pages/Netlify/Vercel. Backend: Render/Railway. Set env: PORT, JWT_SECRET, CORS_ORIGIN.

## Contributor Guidelines
Conventional commits; small components; donâ€™t commit .env or DB.

## License
MIT.

## References
- kc-clintone â€“ The Ultimate Guide to Writing a Great README.md for Your Project
